package interval;

/**
 * Tests for instance methods of MultiIntervalSet.
 */

public class MultiIntervalSetTest {
	// Testing strategy
    // TODO
	
	/*
	 * Testing MultiIntervalSet...
	 */

	// Testing strategy for MultiIntervalSetTest.toString()
	// TODO

	// TODO tests for MultiIntervalSetTest.toString()
}
